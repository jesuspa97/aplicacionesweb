<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>practica3-1</title>

</head>
<body>
    <fieldset> 
        <legend>Formulario</legend>
        <form action="pract31jpc.php" method="post">
            <p>Escribe el ancho y alto (0 < números ≤ 100) y mostraré un rectangulo de estrellas de ese tamaño.</p>
            <p>
                <label for="ancho">Ancho:</label><input type="number" name="ancho" id="ancho" maxwidth="20px">
                <br>
                <label for="alto">Alto:</label><input type="number" name="alto" id="alto" maxwidth="20px">
            </p>
            <p>
                <input type="submit" value="Dibujar" name="dibujar">
                <input type="reset" value="Borrar" name="reset">
            </p>
        </form>
    </fieldset>
    
</body>
</html>
<?php
    if(isset($_REQUEST["dibujar"])) {
        $ancho = $_REQUEST["ancho"];
        $alto = $_REQUEST["alto"];
        if($ancho==""){echo "El campo Ancho no puede estar vacío.<br>";}
        if($alto==""){echo "El campo Alto no puede estar vacío.<br>";}
        for ($i=1; $i <=$alto ; $i++) { 
            for ($l=1; $l <=$ancho ; $l++) { 
                echo "*";
            }
            echo "<br>";
        }
        echo "</p>";
        }
    
?>