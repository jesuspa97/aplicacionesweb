<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>practica3-2</title>
</head>
<body>
    <h1>Jugador 1</h1>
    <?php
    $jugador1=0;
    $jugador2=0;
        $dado11=rand(1,6);
        $dado12=rand(1,6);
        $dado13=rand(1,6);
        $dado14=rand(1,6);
        $dado15=rand(1,6);
        $jugador1= $dado11 + $dado12 + $dado13 + $dado14 + $dado15;
        echo    "<img src='img/$dado11.jpg'>";
        echo    "<img src='img/$dado12.jpg'>";
        echo    "<img src='img/$dado13.jpg'>";
        echo    "<img src='img/$dado14.jpg'>";
        echo    "<img src='img/$dado15.jpg'>";
    ?>
    <h1>Jugador 2</h1>
    <?php
        $dado21=rand(1,6);
        $dado22=rand(1,6);
        $dado23=rand(1,6);
        $dado24=rand(1,6);
        $dado25=rand(1,6);      
        $jugador2 = $dado21 + $dado22 + $dado23 + $dado24 + $dado25;
        echo    "<img src='img/$dado21.jpg'>";
        echo    "<img src='img/$dado22.jpg'>";
        echo    "<img src='img/$dado23.jpg'>";
        echo    "<img src='img/$dado24.jpg'>";
        echo    "<img src='img/$dado25.jpg'>";
    ?>
    <h1>Resultado</h1>
    <?php
        if ($jugador1 > $jugador2) {
            $ganador = 1;
        }
        else {
            $ganador = 2;
        }
        echo "<h2>Jugador 1 = $jugador1 ---- vs ---- Jugador 2 = $jugador2</h2>";
        echo "<h1>El ganador es : El Jugador $ganador</h1>"
    ?>

    
</body>
</html>